BEGIN;

UPDATE MAPY AS m SET nazwa_mapy = v.nazwa
FROM (VALUES
    (1, 'Ancient'),
    (2, 'Anubis'),
    (3, 'Cache'),
    (4, 'Dust2'),
    (5, 'Inferno'),
    (6, 'Mirage'),
    (7, 'Nuke')
) AS v(id_mapy, nazwa)
WHERE m.id_mapy = v.id_mapy;

UPDATE POZYCJE AS p SET id_mapy = v.id_mapy, nazwa_pozycji = v.nazwa
FROM (VALUES
    ( 1, 1, 'B Site'),
    ( 2, 1, 'Cave'),
    ( 3, 1, 'Mid'),
    ( 4, 1, 'Donut'),
    ( 5, 1, 'A Site'),
    ( 6, 2, 'A Site'),
    ( 7, 2, 'A Rotation'),
    ( 8, 2, 'Mid'),
    ( 9, 2, 'B Conn'),
    (10, 2, 'B Site'),
    (11, 3, 'A Site'),
    (12, 3, 'A Rotation'),
    (13, 3, 'Mid'),
    (14, 3, 'B Site'),
    (15, 3, 'B Rotation'),
    (16, 4, 'B Site'),
    (17, 4, 'B Rotation'),
    (18, 4, 'Mid'),
    (19, 4, 'Short'),
    (20, 4, 'Long'),
    (21, 5, 'B Site'),
    (22, 5, 'B Rotation'),
    (23, 5, 'A Site'),
    (24, 5, 'A Short'),
    (25, 5, 'A Rotation'),
    (26, 6, 'A Site'),
    (27, 6, 'A Conn'),
    (28, 6, 'Mid'),
    (29, 6, 'B Short'),
    (30, 6, 'B Site'),
    (31, 7, 'A Door'),
    (32, 7, 'A Hut'),
    (33, 7, 'Ramp'),
    (34, 7, 'Yard'),
    (35, 7, 'Rotation')
) AS v(id_pozycji, id_mapy, nazwa)
WHERE p.id_pozycji = v.id_pozycji;

UPDATE GRACZE SET kraj = 'Czech Republic'         WHERE kraj = 'Chech Republic';
UPDATE GRACZE SET kraj = 'Bosnia and Herzegovina' WHERE kraj = 'Bosnia and Herzegovinia';

UPDATE GRACZE SET imie = TRIM(imie), nazwisko = TRIM(nazwisko), nick = TRIM(nick);

DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 26 AND id_pozycji IN (11, 15);
INSERT INTO GRACZ_POZYCJE VALUES (26, 13) ON CONFLICT DO NOTHING;
INSERT INTO GRACZ_POZYCJE VALUES (26, 31) ON CONFLICT DO NOTHING;

DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 27 AND id_pozycji = 12;
INSERT INTO GRACZ_POZYCJE VALUES (27, 32) ON CONFLICT DO NOTHING;

DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 28 AND id_pozycji = 14;
INSERT INTO GRACZ_POZYCJE VALUES (28, 17) ON CONFLICT DO NOTHING;

INSERT INTO GRACZ_POZYCJE VALUES (51, 1) ON CONFLICT DO NOTHING;
DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 51 AND id_pozycji = 13;
DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 51 AND id_pozycji = 19;
DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 51 AND id_pozycji = 28;
DELETE FROM GRACZ_POZYCJE WHERE id_gracza = 51 AND id_pozycji = 35;

COMMIT;
