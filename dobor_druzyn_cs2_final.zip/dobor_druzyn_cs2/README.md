# Dobór drużyn CS2 – algorytm genetyczny

Program dzieli graczy z bazy na drużyny po 5 osób tak, żeby składy były **równe**
i **dobrze zbilansowane**. Wynik algorytmu genetycznego porównuje z prostym
**doborem wężykiem** (snake draft).

## Pliki

| plik | zawartość |
|---|---|
| `db.py` | połączenie z bazą, zapytania SQL, wczytanie graczy i pozycji, kontrola danych |
| `algorytm.py` | funkcja oceny F, algorytm genetyczny, dobór wężykiem |
| `main.py` | uruchomienie, wydruk drużyn i tabela porównawcza |
| `ctf_db_poprawiony.sql` | poprawiony pełny plik bazy |
| `poprawki_danych.sql` | poprawki dla już istniejącej bazy |
| `sprawdz_pozycje.sql` | lista graczy z błędnymi pozycjami |
| `requirements.txt` | biblioteki Pythona |

## Wzór oceny drużyny

**F = 0,40·R + 0,30·S + 0,20·P + 0,10·K**, każdy składnik ma wartość od 0 do 1.

| | składnik | jak liczony |
|---|---|---|
| **R** | role | start 1,0; **−0,5** za brak IGL-a, **−0,5** za brak snajpera, −0,25 za każdego nadmiarowego IGL-a/snajpera (dwóch snajperów w jednym składzie marnuje rolę, której brakuje innej drużynie) |
| **S** | statystyki (`rating`) | `1 − |śr. rating drużyny − śr. rating wszystkich| / odchylenie std`. Im bliżej średniej, tym drużyny równiejsze |
| **P** | pozycje | dla każdej z 7 map: ilu graczy da się ustawić na **różnych** pozycjach (maksymalne skojarzenie gracz→pozycja), podzielone przez 5. Średnia z 7 map. Każde pokrycie pozycji obniża P |
| **K** | komunikacja (`kraj`) | odsetek par graczy z tego samego kraju: 0 = wszyscy z różnych krajów, 1 = cała piątka z jednego kraju |

Ocena całego podziału (funkcja przystosowania w AG):

```
fitness = średnia(F wszystkich drużyn) − 0,5 · (max F − min F)
```

Pierwszy człon wymusza dobre drużyny, drugi karze za nierówne składy.
Wagi i kary są stałymi na początku `algorytm.py` (`WAGI`, `KARA_BRAK_ROLI`, `LAMBDA`…).

## Algorytm genetyczny

- **Chromosom**: permutacja graczy. Pierwsze 5 genów to drużyna 1, kolejne 5 drużyna 2 itd.
  Jeśli liczba graczy nie dzieli się przez 5, nadmiar idzie do rezerwy.
- **Populacja początkowa**: losowe permutacje (domyślnie 150).
- **Selekcja**: turniejowa (3 osobniki).
- **Krzyżowanie drużynowe** (p = 0,9): dziecko bierze losowo wybrane **całe drużyny**
  od rodzica A, a resztę graczy dopisuje w kolejności z rodzica B. Dzięki temu dobre składy
  nie są rozbijane.
- **Mutacja** (p = 0,5): zamiana 1–3 graczy między różnymi drużynami.
- **Elitaryzm**: 2 najlepsze osobniki przechodzą bez zmian.
- **Stop**: po 800 pokoleniach albo po 250 pokoleniach bez poprawy.

## Dobór wężykiem (punkt odniesienia)

Gracze posortowani malejąco po `rating`. Kolejność wyboru: drużyny 1→15, potem 15→1,
potem znowu 1→15… Wyrównuje siłę, ale ignoruje role, pozycje i kraj.

---

## Jak podpiąć bazę danych

Twoja baza to **PostgreSQL**. Program sam się z nią łączy i pobiera dane trzema zapytaniami (`db.py`):

```sql
SELECT id_gracza, imie, nazwisko, nick, wiek, kraj, rating, rola FROM GRACZE;

-- GRACZ_POZYCJE nie ma id_mapy, więc mapę bierzemy z POZYCJE:
SELECT gp.id_gracza, p.id_mapy, p.id_pozycji
FROM GRACZ_POZYCJE gp JOIN POZYCJE p ON p.id_pozycji = gp.id_pozycji;

SELECT id_mapy, nazwa_mapy FROM MAPY;
```

### 1. Zainstaluj Pythona 3.10+ i sterownik PostgreSQL

```bash
pip install -r requirements.txt
```

(instaluje `psycopg2-binary`, czyli sterownik, przez który Python rozmawia z Postgresem)

### 2. Upewnij się, że baza działa i ma dane

```bash
psql -U postgres -c "CREATE DATABASE cs2"
psql -U postgres -d cs2 -f ctf_db_poprawiony.sql
```

(pomiń, jeśli baza już istnieje; nazwa `cs2` jest przykładowa)

### 3. Podaj dane logowania

Hasła **nie wpisuj w kod**. Przekaż je zmienną środowiskową:

Linux / macOS:
```bash
export DB_PASSWORD='twoje_haslo'
```

Windows (PowerShell):
```powershell
$env:DB_PASSWORD = 'twoje_haslo'
```

Pozostałe parametry podajesz jako argumenty albo zmienne `DB_HOST`, `DB_PORT`,
`DB_USER`, `DB_NAME`:

| argument | zmienna | domyślnie |
|---|---|---|
| `--host` | `DB_HOST` | `localhost` |
| `--port` | `DB_PORT` | `5432` |
| `--user` | `DB_USER` | `postgres` |
| `--baza` | `DB_NAME` | `cs2` |

### 4. Uruchom

```bash
python main.py --baza cs2 --user postgres
```

Opcje algorytmu: `--populacja 200 --pokolenia 1000 --mutacja 0.4 --seed 42`
(`--seed` daje powtarzalny wynik). Pełna lista: `python main.py --help`.

### Inne bazy

Kod obsługuje też MySQL (`--typ mysql`, `pip install pymysql`) i SQLite
(`--typ sqlite --plik cs2.db`). Zapytania są w standardowym SQL, więc działają wszędzie.
Żeby dodać inny silnik, dopisz gałąź w funkcji `polacz()` w `db.py`. Musi zwracać
zwykłe połączenie DB-API (z metodą `.cursor()`).

### Używanie z własnego kodu

```python
from db import polacz, wczytaj_dane
from algorytm import Ocena, algorytm_genetyczny, dobor_wezykiem

conn = polacz("postgres", host="localhost", user="postgres", haslo="...", baza="cs2")
dane = wczytaj_dane(conn); conn.close()

ocena = Ocena(dane)
druzyny, historia = algorytm_genetyczny(ocena, liczba_druzyn=len(dane.gracze) // 5)
for d in druzyny:
    print([dane.gracze[i].nick for i in d], ocena.druzyna(d))
```

---

## Poprawki danych

Pierwotny plik `ctf_db.sql` miał błędne nazwy map i pozycji oraz złe przypisanie
pozycji do map. Do wyboru są dwie drogi:

- **baza od zera**: `ctf_db_poprawiony.sql` (cały plik z poprawionymi tabelami `MAPY`
  i `POZYCJE`, poprawionymi krajami i usuniętymi zbędnymi spacjami),
- **aktualizacja istniejącej bazy**: `poprawki_danych.sql` (najpierw zrób kopię:
  `pg_dump -U postgres cs2 > kopia_cs2.sql`).

Mapy: 1 Ancient, 2 Anubis, 3 Cache, 4 Dust2, 5 Inferno, 6 Mirage, 7 Nuke.
Pozycje: po 5 na mapę (1–5 Ancient, 6–10 Anubis, …, 31–35 Nuke).

### Kto ma złe pozycje

```bash
psql -U postgres -d cs2 -f sprawdz_pozycje.sql
```

Skrypt zawiera dwa zapytania:
1. gracze, którzy na jakiejś mapie nie mają dokładnie jednej pozycji (co mają teraz i z czego mogą wybierać),
2. powtórzenia pozycji w obrębie piątki (gracze 1–5, 6–10, …, 71–75).

Gdy dane są poprawne, oba zapytania zwracają 0 wierszy. Te same ostrzeżenia
wypisuje `main.py` przy starcie.

Algorytm działa także z błędnymi wpisami. Gracz z kilkoma pozycjami na mapie jest
traktowany jako elastyczny, a brak pozycji nie daje kary.

## Przykładowy wynik (Twoje dane po poprawkach, `--seed 1`)

| miara | Wężyk | Genetyczny |
|---|---|---|
| fitness | 0,397 | **0,699** |
| średnie F | 0,611 | **0,775** |
| rozrzut F (max−min) | 0,428 | **0,152** |
| rozrzut śr. ratingu | 0,088 | **0,052** |
| drużyny bez IGL | 6 | **2** |
| drużyny bez snajpera | 4 | **1** |

W bazie jest 13 IGL-i i 14 snajperów na 15 drużyn, więc 2 drużyny bez IGL-a
i 1 bez snajpera to minimum możliwe do osiągnięcia. AG trafia dokładnie w to minimum.
