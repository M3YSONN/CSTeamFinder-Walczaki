SELECT g.id_gracza, g.nick, m.nazwa_mapy,
       COUNT(gp.id_pozycji) AS ile,
       COALESCE(STRING_AGG(p.id_pozycji || ' ' || p.nazwa_pozycji, ', ' ORDER BY p.id_pozycji)
                FILTER (WHERE gp.id_pozycji IS NOT NULL), '-') AS ma_teraz,
       STRING_AGG(p.id_pozycji || ' ' || p.nazwa_pozycji, ', ' ORDER BY p.id_pozycji) AS do_wyboru
FROM GRACZE g
CROSS JOIN MAPY m
JOIN POZYCJE p             ON p.id_mapy = m.id_mapy
LEFT JOIN GRACZ_POZYCJE gp ON gp.id_gracza = g.id_gracza AND gp.id_pozycji = p.id_pozycji
GROUP BY g.id_gracza, g.nick, m.id_mapy, m.nazwa_mapy
HAVING COUNT(gp.id_pozycji) <> 1
ORDER BY g.id_gracza, m.id_mapy;

SELECT (g.id_gracza - 1) / 5 * 5 + 1 || '-' || (g.id_gracza - 1) / 5 * 5 + 5 AS piatka,
       m.nazwa_mapy,
       p.id_pozycji || ' ' || p.nazwa_pozycji AS pozycja,
       STRING_AGG(g.id_gracza || ' ' || g.nick, ', ' ORDER BY g.id_gracza) AS gracze
FROM GRACZ_POZYCJE gp
JOIN GRACZE g  USING (id_gracza)
JOIN POZYCJE p USING (id_pozycji)
JOIN MAPY m    USING (id_mapy)
GROUP BY 1, (g.id_gracza - 1) / 5, m.id_mapy, m.nazwa_mapy, p.id_pozycji, p.nazwa_pozycji
HAVING COUNT(*) > 1
ORDER BY (g.id_gracza - 1) / 5, m.id_mapy;
